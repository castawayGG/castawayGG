import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Конфигурация приложения."""
    
    # Telegram API credentials
    API_ID = os.getenv('TG_API_ID')
    API_HASH = os.getenv('TG_API_HASH')
    
    # Admin credentials
    ADMIN_USERNAME = os.getenv('ADMIN_USERNAME', 'admin')
    ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD')
    
    # Flask secret
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev_key_123')
    
    # Paths
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    SESSIONS_DIR = os.path.join(BASE_DIR, 'sessions')
    LOGS_DIR = os.path.join(BASE_DIR, 'logs')
    STATS_DB_PATH = os.path.join(BASE_DIR, 'stats.json')
    
    # Proxy settings (optional)
    PROXY_ENABLED = os.getenv('PROXY_ENABLED', 'false').lower() == 'true'
    PROXY_TYPE = os.getenv('PROXY_TYPE', 'socks5')
    PROXY_HOST = os.getenv('PROXY_HOST')
    PROXY_PORT = int(os.getenv('PROXY_PORT', 0)) if os.getenv('PROXY_PORT') else None
    PROXY_USERNAME = os.getenv('PROXY_USERNAME')
    PROXY_PASSWORD = os.getenv('PROXY_PASSWORD')
    
    # Create directories if they don't exist
    os.makedirs(SESSIONS_DIR, exist_ok=True)
    os.makedirs(LOGS_DIR, exist_ok=True)
    
    @classmethod
    def get_proxy_tuple(cls):
        """Return proxy tuple for Telethon if enabled."""
        if not cls.PROXY_ENABLED or not all([cls.PROXY_HOST, cls.PROXY_PORT]):
            return None
        
        import socks
        proxy_type = socks.SOCKS5 if cls.PROXY_TYPE == 'socks5' else socks.HTTP
        
        if cls.PROXY_USERNAME and cls.PROXY_PASSWORD:
            return (proxy_type, cls.PROXY_HOST, cls.PROXY_PORT, True, 
                    cls.PROXY_USERNAME, cls.PROXY_PASSWORD)
        return (proxy_type, cls.PROXY_HOST, cls.PROXY_PORT, False)