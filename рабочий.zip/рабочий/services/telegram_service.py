#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
telegram_service.py - Сервис для работы с Telegram API
Версия: 3.1 - Исправлено тестирование прокси
"""

import os
import asyncio
import time
import socks
from telethon import TelegramClient, errors, functions
from telethon.sessions import StringSession
from config import Config

# Global client cache to avoid recreating clients
_client_cache = {}

def get_proxy_tuple(proxy_data=None):
    """Get proxy tuple from config or proxy data."""
    if proxy_data:
        # Use provided proxy data
        if proxy_data.get('type') == 'socks5':
            proxy_type = socks.SOCKS5
        elif proxy_data.get('type') == 'socks4':
            proxy_type = socks.SOCKS4
        else:
            proxy_type = socks.HTTP
        
        if proxy_data.get('username') and proxy_data.get('password'):
            return (proxy_type, proxy_data['host'], proxy_data['port'], True,
                    proxy_data['username'], proxy_data['password'])
        return (proxy_type, proxy_data['host'], proxy_data['port'], False)
    
    # Use config proxy
    if not Config.PROXY_ENABLED:
        return None
    
    if Config.PROXY_TYPE == 'socks5':
        proxy_type = socks.SOCKS5
    elif Config.PROXY_TYPE == 'socks4':
        proxy_type = socks.SOCKS4
    else:
        proxy_type = socks.HTTP
    
    if Config.PROXY_USERNAME and Config.PROXY_PASSWORD:
        return (proxy_type, Config.PROXY_HOST, Config.PROXY_PORT, True,
                Config.PROXY_USERNAME, Config.PROXY_PASSWORD)
    return (proxy_type, Config.PROXY_HOST, Config.PROXY_PORT, False)

# ============================================
# УЛУЧШЕННАЯ ФУНКЦИЯ ТЕСТИРОВАНИЯ ПРОКСИ
# ============================================

async def test_proxy_async(proxy_data):
    """
    Улучшенное тестирование прокси с детальной диагностикой.
    Returns: (success, speed_ms, error_message)
    """
    start_time = time.time()
    
    # Извлекаем данные прокси
    proxy_host = proxy_data.get('host')
    proxy_port = proxy_data.get('port')
    proxy_type = proxy_data.get('type', 'socks5')
    proxy_user = proxy_data.get('username')
    proxy_pass = proxy_data.get('password')
    
    if not proxy_host or not proxy_port:
        return False, None, "Missing host or port"
    
    # Создаем кортеж прокси для Telethon
    try:
        if proxy_type == 'socks5':
            proxy_type_const = socks.SOCKS5
        elif proxy_type == 'socks4':
            proxy_type_const = socks.SOCKS4
        else:
            proxy_type_const = socks.HTTP
        
        if proxy_user and proxy_pass:
            proxy = (proxy_type_const, proxy_host, proxy_port, True, proxy_user, proxy_pass)
        else:
            proxy = (proxy_type_const, proxy_host, proxy_port, False)
            
    except Exception as e:
        return False, None, f"Proxy configuration error: {e}"
    
    # Пробуем несколько методов проверки
    client = None
    try:
        # Создаем клиент с StringSession (без сохранения)
        client = TelegramClient(StringSession(), Config.API_ID, Config.API_HASH, proxy=proxy)
        
        # Устанавливаем таймаут подключения
        await client.connect()
        
        # Метод 1: Пытаемся получить конфигурацию (не требует авторизации)
        try:
            # Получаем информацию о дата-центрах
            config = await client(functions.help.GetConfigRequest())
            if config and hasattr(config, 'dc_options'):
                speed = round((time.time() - start_time) * 1000)
                await client.disconnect()
                return True, speed, None
        except Exception as e:
            # Если не сработало, пробуем следующий метод
            pass
        
        # Метод 2: Пробуем получить себя (может вернуть ошибку авторизации, но это ок)
        try:
            await client.get_me()
            speed = round((time.time() - start_time) * 1000)
            await client.disconnect()
            return True, speed, None
        except errors.UnauthorizedError:
            # Это нормально - мы не авторизованы, но прокси работает
            speed = round((time.time() - start_time) * 1000)
            await client.disconnect()
            return True, speed, None
        except Exception as e:
            # Запоминаем ошибку для диагностики
            last_error = str(e)
        
        # Метод 3: Пробуем получить диалоги (один)
        try:
            await client.get_dialogs(limit=1)
            speed = round((time.time() - start_time) * 1000)
            await client.disconnect()
            return True, speed, None
        except errors.UnauthorizedError:
            speed = round((time.time() - start_time) * 1000)
            await client.disconnect()
            return True, speed, None
        except Exception as e:
            # Если все методы не сработали, возвращаем последнюю ошибку
            await client.disconnect()
            return False, None, f"All methods failed: {e}"
            
    except errors.FloodWaitError as e:
        # Flood wait означает, что прокси работает (Telegram ответил)
        speed = round((time.time() - start_time) * 1000)
        if client:
            await client.disconnect()
        return True, speed, f"Flood wait: {e.seconds}s"
        
    except OSError as e:
        if client:
            await client.disconnect()
        return False, None, f"Network error: {e}"
        
    except Exception as e:
        if client:
            await client.disconnect()
        return False, None, str(e)
        
    finally:
        if client:
            try:
                await client.disconnect()
            except:
                pass

# ============================================
# ФУНКЦИЯ ДЛЯ ОТПРАВКИ КОДА
# ============================================

async def send_code_telethon(phone, session_id):
    """
    Send authentication code to phone.
    Returns: dict with status and phone_code_hash
    """
    session_path = os.path.join(Config.SESSIONS_DIR, f"{session_id}.session")
    proxy = get_proxy_tuple()
    
    try:
        client = TelegramClient(session_path, Config.API_ID, Config.API_HASH, proxy=proxy)
        await client.connect()
        
        # Check if already authorized
        if await client.is_user_authorized():
            return {'status': 'already_authorized'}
        
        # Send code request
        result = await client.send_code_request(phone)
        
        # Store client in cache for later use
        _client_cache[session_id] = client
        
        return {
            'status': 'success',
            'phone_code_hash': result.phone_code_hash,
            'timeout': result.timeout
        }
        
    except errors.FloodWaitError as e:
        return {'status': 'error', 'message': f'Flood wait: {e.seconds}s'}
    except Exception as e:
        return {'status': 'error', 'message': str(e)}

# ============================================
# ФУНКЦИЯ ДЛЯ ВХОДА ПО КОДУ
# ============================================

async def sign_in_telethon(code, session_id, phone, phone_code_hash):
    """
    Sign in with code.
    Returns: dict with status and session data if success
    """
    session_path = os.path.join(Config.SESSIONS_DIR, f"{session_id}.session")
    proxy = get_proxy_tuple()
    
    try:
        # Try to get cached client or create new
        client = _client_cache.get(session_id)
        if not client:
            client = TelegramClient(session_path, Config.API_ID, Config.API_HASH, proxy=proxy)
            await client.connect()
        
        try:
            # Attempt sign in
            user = await client.sign_in(phone, code, phone_code_hash=phone_code_hash)
            
            # Success - save session file
            await client.disconnect()
            
            # Get session string for backup
            session_string = StringSession.save(client.session)
            
            return {
                'status': 'success',
                'user_id': user.id,
                'username': user.username,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'phone': user.phone,
                'session_string': session_string
            }
            
        except errors.SessionPasswordNeededError:
            # 2FA required
            return {'status': 'password_needed'}
            
        except errors.PhoneCodeInvalidError:
            return {'status': 'error', 'message': 'Invalid code'}
            
        except errors.PhoneCodeExpiredError:
            return {'status': 'error', 'message': 'Code expired'}
            
    except Exception as e:
        return {'status': 'error', 'message': str(e)}
    finally:
        if session_id in _client_cache:
            del _client_cache[session_id]

# ============================================
# ФУНКЦИЯ ДЛЯ ВХОДА С 2FA
# ============================================

async def sign_in_2fa(password, session_id, phone):
    """
    Complete 2FA sign in.
    """
    session_path = os.path.join(Config.SESSIONS_DIR, f"{session_id}.session")
    proxy = get_proxy_tuple()
    
    try:
        client = TelegramClient(session_path, Config.API_ID, Config.API_HASH, proxy=proxy)
        await client.connect()
        
        user = await client.sign_in(password=password)
        
        # Success
        session_string = StringSession.save(client.session)
        await client.disconnect()
        
        return {
            'status': 'success',
            'user_id': user.id,
            'username': user.username,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'phone': user.phone,
            'session_string': session_string
        }
        
    except errors.PasswordHashInvalidError:
        return {'status': 'error', 'message': 'Invalid password'}
    except errors.FloodWaitError as e:
        return {'status': 'error', 'message': f'Flood wait: {e.seconds}s'}
    except Exception as e:
        return {'status': 'error', 'message': str(e)}

# ============================================
# ФУНКЦИЯ ДЛЯ ПРОВЕРКИ API CREDENTIALS
# ============================================

async def check_api_credentials(api_id, api_hash):
    """
    Проверка работоспособности API credentials.
    
    Args:
        api_id: API ID из my.telegram.org
        api_hash: API Hash из my.telegram.org
    
    Returns:
        dict: Результат проверки с деталями
    """
    result = {
        'success': False,
        'valid': False,
        'message': '',
        'details': {}
    }
    
    try:
        # Создаем временный клиент без сессии
        client = TelegramClient(StringSession(), int(api_id), api_hash, proxy=get_proxy_tuple())
        
        # Пробуем подключиться
        await client.connect()
        
        # Проверяем соединение
        if not await client.is_user_authorized():
            # Это нормально - мы не авторизованы, но API работает
            result['valid'] = True
            result['success'] = True
            result['message'] = 'API credentials valid'
            result['details'] = {
                'connected': True,
                'authorized': False,
                'api_id': api_id
            }
        else:
            # Странно, но тоже ок
            result['valid'] = True
            result['success'] = True
            result['message'] = 'API credentials valid (already authorized)'
            result['details'] = {
                'connected': True,
                'authorized': True,
                'api_id': api_id
            }
        
        await client.disconnect()
        
    except errors.FloodWaitError as e:
        result['message'] = f'Flood wait: {e.seconds}s'
        result['details'] = {'flood_wait': e.seconds}
        
    except errors.ApiIdInvalidError:
        result['message'] = 'Invalid API ID'
        result['details'] = {'error': 'api_id_invalid'}
        
    except Exception as e:
        result['message'] = f'Connection error: {str(e)}'
        result['details'] = {'error': str(e)}
    
    return result

# ============================================
# ФУНКЦИЯ ДЛЯ ПОЛУЧЕНИЯ ИНФОРМАЦИИ ОБ АККАУНТЕ
# ============================================

async def get_account_info(session_file):
    """
    Get information about an authorized account from session file.
    """
    proxy = get_proxy_tuple()
    
    try:
        client = TelegramClient(session_file, Config.API_ID, Config.API_HASH, proxy=proxy)
        await client.connect()
        
        if await client.is_user_authorized():
            me = await client.get_me()
            
            # Get additional info
            info = {
                'id': me.id,
                'phone': me.phone,
                'username': me.username,
                'first_name': me.first_name,
                'last_name': me.last_name,
                'premium': getattr(me, 'premium', False),
                'verified': getattr(me, 'verified', False),
                'mutual_contact': getattr(me, 'mutual_contact', False),
                'bot': me.bot if hasattr(me, 'bot') else False
            }
            
            # Try to get DC info
            try:
                dc_id = client.session.dc_id
                info['dc_id'] = dc_id
            except:
                pass
            
            await client.disconnect()
            return info
        
        await client.disconnect()
        return None
        
    except Exception as e:
        return {'error': str(e)}